package com.kafka.Message;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MessageApplicationTests {

	@Test
	void contextLoads() {
	}

}
